from flask import Blueprint, jsonify, request, session
from flask_cors import cross_origin
from pymongo import MongoClient
import os

books_bp = Blueprint('books', __name__)

# MongoDB connection
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client["bookstore"]
books_collection = db["books"]

def is_valid_book(book):
    """Check if a book document has all required fields"""
    required_fields = ['BookID', 'BookTitle', 'AuthorName', 'BookPrice', 'BookQuantity']
    
    for field in required_fields:
        if field not in book or book[field] is None:
            return False
            
    # Additional validation
    if not isinstance(book['BookID'], int):
        return False
    if not isinstance(book['BookPrice'], (int, float)):
        return False  
    if not isinstance(book['BookQuantity'], int):
        return False
    if book['BookQuantity'] < 0:
        return False
        
    return True

@books_bp.route('/')
@cross_origin(origins=['http://localhost:3000', 'http://localhost:3001'], supports_credentials=True)
def get_all_books():
    """Get books with data validation"""
    try:
        print("=== BOOKS ENDPOINT CALLED ===", flush=True)
        
        # Start with an even smaller limit to prevent timeouts
        limit = 10  # Reduced from 20 to 10
        
        # Get books from database
        print("About to query database...", flush=True)
        all_books = list(books_collection.find({}).sort("BookID", 1).limit(limit * 2))  # Get extra in case some are invalid
        print(f"Database query completed. Retrieved {len(all_books)} books", flush=True)
        
        # Filter out invalid books
        valid_books = []
        invalid_count = 0
        
        for book in all_books:
            # Remove ObjectId first
            if '_id' in book:
                del book['_id']
                
            if is_valid_book(book):
                # Ensure all required fields have default values
                book.setdefault('BookPublisher', 'Unknown Publisher')
                book.setdefault('BookPublicationDate', 'Unknown Date')
                valid_books.append(book)
            else:
                invalid_count += 1
                print(f"Invalid book found: {book}", flush=True)
                
            # Stop when we have enough valid books
            if len(valid_books) >= limit:
                break
        
        print(f"Found {len(valid_books)} valid books, {invalid_count} invalid books", flush=True)
        
        # Sort by BookID for consistent ordering
        valid_books.sort(key=lambda x: x.get('BookID', 0))
        
        total_time = time.time() - start_time
        print(f"Returning {len(valid_books)} books successfully in {total_time:.2f}s", flush=True)
        return jsonify(valid_books)
        
    except Exception as e:
        print(f"=== ERROR in get_all_books: {e} ===", flush=True)
        import traceback
        print(f"Full traceback: {traceback.format_exc()}", flush=True)
        return jsonify({'error': 'Failed to fetch books', 'details': str(e)}), 500

@books_bp.route('/test')
def test_books():
    """Test endpoint with data validation"""
    try:
        print("=== TEST BOOKS ENDPOINT CALLED ===", flush=True)
        
        # Get more books than needed in case some are invalid
        all_books = list(books_collection.find({}).sort("BookID", 1).limit(20))
        print(f"Test: Retrieved {len(all_books)} books from database", flush=True)
        
        # Filter for valid books
        valid_books = []
        invalid_books = []
        
        for book in all_books:
            if '_id' in book:
                del book['_id']
                
            if is_valid_book(book):
                # Ensure all fields have values
                book.setdefault('BookPublisher', 'Unknown Publisher')
                book.setdefault('BookPublicationDate', 'Unknown Date')
                valid_books.append(book)
            else:
                invalid_books.append(book)
                
            # Stop when we have 5 valid books
            if len(valid_books) >= 5:
                break
        
        print(f"Test: Found {len(valid_books)} valid books, {len(invalid_books)} invalid books", flush=True)
        
        if invalid_books:
            print(f"Invalid books found: {invalid_books}", flush=True)
        
        result = {
            'status': 'success',
            'count': len(valid_books),
            'books': valid_books,
            'invalid_count': len(invalid_books),
            'sample_invalid': invalid_books[:2] if invalid_books else []
        }
        
        return jsonify(result)
        
    except Exception as e:
        print(f"=== TEST BOOKS ERROR: {e} ===", flush=True)
        return jsonify({'error': 'Test failed', 'details': str(e)}), 500

@books_bp.route('/debug')
def debug_books():
    """Debug endpoint with data quality check"""
    try:
        print("=== DEBUG BOOKS ENDPOINT CALLED ===", flush=True)
        
        # Test MongoDB connection
        client.admin.command('ping')
        
        # Get database info
        collections = db.list_collection_names()
        total_books = books_collection.count_documents({})
        
        # Check data quality - sample first 20 books
        sample_books = list(books_collection.find({}).limit(20))
        valid_count = 0
        invalid_books = []
        
        for book in sample_books:
            if '_id' in book:
                del book['_id']
            if is_valid_book(book):
                valid_count += 1
            else:
                invalid_books.append(book)
        
        # Get a valid sample book
        valid_sample = None
        for book in sample_books:
            if '_id' in book:
                del book['_id']
            if is_valid_book(book):
                valid_sample = book
                break
        
        debug_info = {
            'mongodb_connected': True,
            'database_name': db.name,
            'collections': collections,
            'books_collection_exists': 'books' in collections,
            'total_books_count': total_books,
            'sample_size': len(sample_books),
            'valid_in_sample': valid_count,
            'invalid_in_sample': len(invalid_books),
            'data_quality_ratio': f"{valid_count}/{len(sample_books)}",
            'valid_sample_book': valid_sample,
            'invalid_samples': invalid_books[:3]  # Show first 3 invalid books
        }
        
        print(f"Debug info: {debug_info}", flush=True)
        return jsonify(debug_info)
        
    except Exception as e:
        print(f"=== DEBUG ERROR: {e} ===", flush=True)
        return jsonify({
            'mongodb_connected': False,
            'error': str(e),
            'error_type': type(e).__name__
        }), 500

@books_bp.route('/<int:book_id>')
def get_book_by_id(book_id):
    """Get a specific book by its ID with validation"""
    try:
        print(f"Fetching book with ID: {book_id}", flush=True)
        book = books_collection.find_one({"BookID": book_id})
        
        if not book:
            return jsonify({'error': 'Book not found'}), 404
            
        # Remove ObjectId for JSON serialization
        if '_id' in book:
            del book['_id']
            
        if not is_valid_book(book):
            return jsonify({'error': 'Book data is invalid'}), 422
            
        # Ensure all fields have values
        book.setdefault('BookPublisher', 'Unknown Publisher')
        book.setdefault('BookPublicationDate', 'Unknown Date')
            
        return jsonify(book)
        
    except Exception as e:
        print(f"Error fetching book {book_id}: {e}", flush=True)
        return jsonify({'error': 'Failed to fetch book', 'details': str(e)}), 500

@books_bp.route('/search')
def search_books():
    """Search books with validation"""
    try:
        query = request.args.get('q', '').strip()
        print(f"Search query: '{query}'", flush=True)
        
        if not query:
            return jsonify([])
        
        # Create case-insensitive search across multiple fields
        search_filter = {
            "$and": [
                # Must have required fields
                {"BookID": {"$exists": True, "$ne": None}},
                {"BookTitle": {"$exists": True, "$ne": None}},
                {"AuthorName": {"$exists": True, "$ne": None}},
                # Search criteria
                {"$or": [
                    {"BookTitle": {"$regex": query, "$options": "i"}},
                    {"AuthorName": {"$regex": query, "$options": "i"}},
                    {"BookPublisher": {"$regex": query, "$options": "i"}}
                ]}
            ]
        }
        
        books = list(books_collection.find(search_filter).limit(50))
        print(f"Search found {len(books)} books", flush=True)
        
        # Validate and clean books
        valid_books = []
        for book in books:
            if '_id' in book:
                del book['_id']
            if is_valid_book(book):
                book.setdefault('BookPublisher', 'Unknown Publisher')
                book.setdefault('BookPublicationDate', 'Unknown Date')
                valid_books.append(book)
        
        # Sort by relevance
        def sort_key(book):
            title_match = query.lower() in book['BookTitle'].lower()
            author_match = query.lower() in book['AuthorName'].lower()
            
            if title_match:
                return 0
            elif author_match:
                return 1
            else:
                return 2
        
        valid_books.sort(key=sort_key)
        
        return jsonify(valid_books)
        
    except Exception as e:
        print(f"Error searching books: {e}", flush=True)
        return jsonify({'error': 'Failed to search books', 'details': str(e)}), 500